#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "541b5a380"     # abbreviated commit hash
commit = "541b5a3809a55bbe6d550e7ea1c022526f6e64d8"  # commit hash
date = "2017-09-06 10:29:20 +0200"   # commit date
author = "Jonathan Springer <springermac@users.noreply.github.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Tests/CI: Fix: psutil 5.3.0 caused intermittent failures on AppVeyor

"""
